<?php

namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use function Sodium\add;


class LocationController extends Controller
{
    public function index(){
        $citys = Storage::get('public/location.json');
        return $citys;
    }

    public function district(){
        $districts = Storage::get('public/district.json');
        return $districts;
    }

    public function ward(){
        $wards = Storage::get('public/ward.json');
        return $wards;
    }

    public function index_id($id){
        $districts = Storage::get('public/district.json');
        $object_district = json_decode($districts,true);
        $list_districts = array();
        foreach ($object_district as $item){
            if ($item['province_code']==$id)
                $list_districts[] = $item;
        }
        if (!empty($list_districts))
            return json_encode($list_districts);
        $json_string =
        '
            {
                "type": "about:blank",
                "title": "Not Found",
                "status": 404,
                "detail": "Not Found"
            }
        ';
        return json_decode($json_string);
    }

    public function district_id($id){
        $wards = Storage::get('public/ward.json');
        $object_wards = json_decode($wards,true);
        $list_wards = array();
        foreach ($object_wards as $item){
            if ($item['district_code']==$id)
                $list_wards[] = $item;
        }
        if (!empty($list_wards))
            return json_encode($list_wards);
        $json_string =
            '
            {
                "type": "about:blank",
                "title": "Not Found",
                "status": 404,
                "detail": "Not Found"
            }
        ';
        return json_decode($json_string);
    }
}
